Add future recovered-footage clips here.
