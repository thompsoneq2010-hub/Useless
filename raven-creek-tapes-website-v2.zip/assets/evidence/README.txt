Add fictional case documents, photos, newspaper clippings and evidence here.
