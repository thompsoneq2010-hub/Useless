Add the six character posters here: Elijah, Aiden, Lucas, Steven, Colin, Noah.
